package gui;

import factory.DocumentoFactory;
import processors.DocumentoProcessor;

import javax.swing.*;
import java.io.File;

public class VentanaPrincipal extends JFrame {

    JComboBox<String> tipoDocumento;
    JButton botonArchivo;
    File archivoSeleccionado;

    public VentanaPrincipal() {

        setTitle("GlobalDocs");
        setSize(400,250);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        tipoDocumento = new JComboBox<>(new String[]{
                "Factura", "Contrato"
        });

        tipoDocumento.setBounds(120,30,150,25);
        add(tipoDocumento);

        botonArchivo = new JButton("Seleccionar archivo");
        botonArchivo.setBounds(100,80,180,30);
        add(botonArchivo);

        JButton procesar = new JButton("Procesar");
        procesar.setBounds(130,130,120,30);
        add(procesar);

        botonArchivo.addActionListener(e -> {

            JFileChooser chooser = new JFileChooser();
            int resultado = chooser.showOpenDialog(null);

            if(resultado == JFileChooser.APPROVE_OPTION){
                archivoSeleccionado = chooser.getSelectedFile();
            }

        });

        procesar.addActionListener(e -> {

            try {

                String tipo = (String) tipoDocumento.getSelectedItem();

                DocumentoProcessor procesador =
                        DocumentoFactory.crearProcesador(tipo);

                procesador.procesar(archivoSeleccionado);

                JOptionPane.showMessageDialog(this,
                        "Documento procesado correctamente");

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(this,
                        "Error: " + ex.getMessage());

            }

        });

    }
}