package processors;

import java.io.File;

public abstract class DocumentoProcessor {

    public abstract void procesar(File archivo);

}