package processors;

import java.io.File;

public class ContratoProcessor extends DocumentoProcessor {

    @Override
    public void procesar(File archivo) {
        System.out.println("Procesando contrato: " + archivo.getName());
    }

}