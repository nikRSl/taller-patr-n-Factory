package processors;

import java.io.File;

public class FacturaProcessor extends DocumentoProcessor {

    @Override
    public void procesar(File archivo) {
        System.out.println("Procesando factura: " + archivo.getName());
    }

}