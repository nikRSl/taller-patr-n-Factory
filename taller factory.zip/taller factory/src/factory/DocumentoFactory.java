package factory;
import processors.ContratoProcessor;
import processors.FacturaProcessor;
import processors.DocumentoProcessor;

public class DocumentoFactory {

    public static DocumentoProcessor crearProcesador(String tipo) {

        switch (tipo) {

            case "Factura":
                return new FacturaProcessor();

            case "Contrato":
                return new ContratoProcessor();

            default:
                throw new IllegalArgumentException("Tipo no soportado");
        }

    }

}